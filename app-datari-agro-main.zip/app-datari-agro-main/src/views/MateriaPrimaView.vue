<template>
    <div id="home">
      <div id="head">
        <v-app-bar color="light-blue darken-2" class="rounded" flat dark>
          <v-row justify="start" align="center" no-gutters>
            <h2 class="font-weight-light mr-4 mb-0">ENCUESTA AGRO 2024</h2>
            
            <!-- Botones de navegación al lado del título -->
            <v-btn
              v-for="(tab, index) in tabs"
              :key="index"
              text
              :class="{'white--text': activeTab === index, 'font-weight-bold': activeTab === index}"
              @click="navigateTo(index)"
            >
              {{ tab.label }}
            </v-btn>
          </v-row>
        </v-app-bar>
  
      </div>
      <div id="body" class="mt-2">
            <v-card flat class="rounded" style="height: 80vh;" >  
                <v-row>
                    <v-col cols="3">  
                        <v-card height="70vh">
                            <h4>Materias Prima</h4>
                            <v-img
                            :width="300"
                            cover
                            src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                            >

                            </v-img>
                        </v-card>
                    </v-col>
                    <v-col cols="9">
                        <v-card height="70vh">
                            <h4>Aca va el Sankey</h4>
                            <v-img
                            :width="700"
                            cover
                            src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                            >

                            </v-img>
                        </v-card>

                    </v-col>
                </v-row>
            </v-card>

      </div>
    </div>
  </template>
  
  <script>
  
    export default {
    name: 'Home',
    data() {
      return {
        activeTab: 2,
        tabs: [
          { label: 'Caracterización', path: '/caracterizacion/' },
          { label: 'Rating', path: '/rating/' },
          { label: 'Materia prima', path: '/materiaprima/' },
        ],
      };
    },
    components: {
    },
      methods:{
        navigateTo(index) {
        this.activeTab = index;
        this.$router.push({ path: this.tabs[index].path });
      },
      },
      created(){
      }
    }
    import axios from 'axios';
  </script>
  
  <style scoped>
  .v-btn.white--text {
    background-color: white;
    color: black !important;
  }
  </style>