<template>
  <div id="home">
    <div id="head">
      <v-app-bar color="light-blue darken-2" class="rounded" flat dark>
        <v-row justify="start" align="center" no-gutters>
          <h2 class="font-weight-light mr-4 mb-0">ENCUESTA AGRO 2024</h2>
          
          <!-- Botones de navegación al lado del título -->
          <v-btn
            v-for="(tab, index) in tabs"
            :key="index"
            text
            :class="{'white--text': activeTab === index, 'font-weight-bold': activeTab === index}"
            @click="navigateTo(index)"
          >
            {{ tab.label }}
          </v-btn>
        </v-row>
      </v-app-bar>
    </div>
    <div id="body" class="mt-2">
      <v-row>
        <v-col cols="12">
          <v-card flat class="rounded" style="height: 80vh;">
            <v-row>
              <v-col>
                <infoCardSimpleV2 
                  :title="myTitle"
                  :icon="'mdi-information'" 
                  :subtitle="mySubtitle"
                  :data="myArray[0].option"            
                />
              </v-col>
              <!-- <ul> -->
                
                <!-- <li> {{ 'Id_propietario: '+id }}</li>
                <li> {{ tipo_empresa }}</li>
                <li> {{ tamano_empresa }}</li>
                <li> {{ region }}</li>
                <li> {{ comuna }}</li>
                <li> {{ distancia_predio_arica }}</li>
                <li> {{ ubicacion_predio }}</li>
                <li> {{ propiedad_predio }}</li> -->
              <!-- </ul> -->
            </v-row>
          </v-card>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import infoCardSimpleV2 from '../components/cards/infoCardSimple.vue';

axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`; // Configuración global de axios

export default {
  name: 'Home',
  data() {
    return {
      activeTab: 0,
      user_id: localStorage.getItem('user_id'), // Recupera el user_id del localStorage
      tabs: [
        { label: 'Caracterización', path: '/caracterizacion/' },
        { label: 'Rating', path: '/rating/' },
        { label: 'Materia prima', path: '/materiaprima/' },
      ],
      generalData: {
        productores: null,
        cultivos: null,
        recursosHidricos: null,
        suelo: null,
        residuos: null,
        energia: null,
        certificaciones: null,
        comercializacion: null,
        trabajadores: null,
        trazabilidad: null,
        // Agrega más entidades si es necesario
      },
      loading: true, // Para indicar que los datos se están cargando
      myTitle: 'Prueba',
      mySubtitle: 'Prueba',
      myArray: [{ option: 'orange' }]
    };
  },
  components: {
    infoCardSimpleV2
  },
  methods: {
    navigateTo(index) {
      this.activeTab = index;
      this.$router.push({ path: this.tabs[index].path });
    },

    
    // async fetchdataProductores() {
    //   try {
    //     const response = await axios.get(`http://localhost:8000/api-agro/productores/${this.user_id}/`);
    //     console.log(response.data);
    //     this.id = response.data.id;
    //     this.tipo_empresa = response.data.tipo_empresa;
    //     this.tamano_empresa = response.data.tamano_empresa;
    //     this.region = response.data.region;
    //     this.comuna = response.data.comuna;
    //     this.distancia_predio_arica = response.data.distancia_predio_arica;
    //     this.ubicacion_predio = response.data.ubicacion_predio;
    //     this.propiedad_predio = response.data.propiedad_predio;
    //   } catch (error) {
    //     console.error('Error al obtener los datos de productores:', error);
    //   }
    // },
    // async fetchdataEnergia() {
    //   try {
    //     const response = await axios.get(`http://localhost:8000/api-agro/energia/${this.user_id}/`);
    //     console.log(response.data);
    //     this.id = response.data.id;
    //     this.registro_consumo_energia = response.data.registro_consumo_energia;
    //     this.bps_consumo_energia= response.data.bps_consumo_energia;
    //     this.consumo_anual_energia = response.data.region;
    //     this.comuna = response.data.comuna;
    //     this.distancia_predio_arica = response.data.distancia_predio_arica;
    //     this.ubicacion_predio = response.data.ubicacion_predio;
    //     this.propiedad_predio = response.data.propiedad_predio;
    //   } catch (error) {
    //     console.error('Error al obtener los datos de productores:', error);
    //   }
    // }
    async fetchAllData() {
    try {
      // Opcional: Muestra un indicador de carga
      this.loading = true;

      const [
        productores,
        cultivos,
        recursosHidricos,
        suelo,
        residuos,
        energia,
        certificaciones,
        comercializacion,
        trabajadores,
        trazabilidad,
      ] = await Promise.all([
        axios.get(`http://localhost:8000/api-agro/productores/`),
        // axios.get(`http://localhost:8000/api-agro/productores/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/cultivos/`),
        // axios.get(`http://localhost:8000/api-agro/cultivos/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/recursos_hidricos/`),
        // axios.get(`http://localhost:8000/api-agro/recursos_hidricos/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/suelo/`),
        // axios.get(`http://localhost:8000/api-agro/suelo/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/residuos/`),
        // axios.get(`http://localhost:8000/api-agro/residuos/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/energia/`),
        // axios.get(`http://localhost:8000/api-agro/energia/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/certificaciones/`),
        // axios.get(`http://localhost:8000/api-agro/certificaciones/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/comercializacion/`),
        // axios.get(`http://localhost:8000/api-agro/comercializacion/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/trabajadores/`),
        // axios.get(`http://localhost:8000/api-agro/trabajadores/${this.user_id}/`),
        axios.get(`http://localhost:8000/api-agro/trazabilidad/`),
        // axios.get(`http://localhost:8000/api-agro/trazabilidad/${this.user_id}/`),
        // Agrega otras solicitudes si es necesario
      ]);

      // Asigna las respuestas a la data general
      this.generalData.productores = productores.data;
      this.generalData.cultivos = cultivos.data;
      this.generalData.recursosHidricos = recursosHidricos.data;
      this.generalData.suelo = suelo.data;
      this.generalData.residuos = residuos.data;
      this.generalData.energia = energia.data;
      this.generalData.certificaciones = certificaciones.data;
      this.generalData.comercializacion = comercializacion.data;
      this.generalData.trabajadores = trabajadores.data;
      this.generalData.trazabilidad = trazabilidad.data;

      console.log('Data cargada:', this.generalData);
    } catch (error) {
      console.error('Error al cargar los datos:', error);
    } finally {
      // Oculta el indicador de carga
      this.loading = false;
    }
  },

  },
  created() {
    this.fetchAllData();
  }
}
</script>

<style scoped>
.v-btn.white--text {
  background-color: white;
  color: black !important;
}
</style>
