<template>
  <div id="home">
    <div id="head">
      <v-app-bar color="light-blue darken-2" class="rounded" flat dark>
        <v-row justify="start" align="center" no-gutters>
          <h2 class="font-weight-light mr-4 mb-0">ENCUESTA AGRO 2024</h2>
          
          <!-- Botones de navegación al lado del título -->
          <v-btn
            v-for="(tab, index) in tabs"
            :key="index"
            text
            :class="{'white--text': activeTab === index, 'font-weight-bold': activeTab === index}"
            @click="navigateTo(index)"
          >
            {{ tab.label }}
          </v-btn>
        </v-row>
      </v-app-bar>

    </div>
    <div id="body" class="mt-2">
      <v-row>
        <v-col cols=12>
          <v-card flat class="rounded" style="height: 80vh;" >  
            <v-row>
              <v-col cols="6">
                <v-row>
                  <v-col cols="4">
                    <v-card height="200">
                      <h2>Grafico circular</h2>
                    </v-card>
                  </v-col>
                  <v-col cols="4">
                    <v-card height="200">
                      <h3>Tipo de Empresa</h3>
                    </v-card>
                  </v-col >
                  <v-col cols="4">
                    <v-card height="100">
                      <v-col>
                        <h3>Empresas</h3>
                      </v-col>
                    </v-card>
                    <v-card height="100">
                      <v-col>
                        <h3>Propiedad</h3>
                      </v-col>
                    </v-card>
                  </v-col>
                  
                </v-row>
                <v-row>
                  <v-col cols="12">
                    <v-card height="200">
                      <h2>
                        Acá va el MAPTREE
                      </h2> 
                    </v-card>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col cols="12">
                    <v-row>
                      <v-col cols="4">
                        <v-card height="200">
                          <h2>Otro Elemento</h2>
                        </v-card>
                      </v-col>
                      <v-col cols="4">
                        <v-card height="200">
                          <h2>Otro Elemento</h2>
                        </v-card>
                      </v-col>
                      <v-col cols="4">
                        <v-card height="200">
                          <h2>Otro Elemento</h2>
                        </v-card>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols=6>
                  <h1>Acá va el mapa</h1>
                  <Map_region_comunas 
                  :data="data_detail_mapa_region" 
                  :nombre_comuna="comuna_selected"  
                />
              </v-col>
            </v-row>
          </v-card>
        </v-col>
      </v-row>

    </div>
  </div>
</template>

<script>
import Map_region_comunas from '../components/maps/map_region_comunas.vue';
export default {
  name: 'Home',
  data() {
    return {
      activeTab: 0,
      tabs: [
        { label: 'Caracterización', path: '/caracterizacion/' },
        { label: 'Rating', path: '/rating/' },
        { label: 'Materia prima', path: '/materiaprima/' },
      ],
    };
  },
  components: {
    Map_region_comunas
  },
    methods:{
      navigateTo(index) {
      this.activeTab = index;
      this.$router.push({ path: this.tabs[index].path });
    },
    
    },
    created(){
    },
    mounted(){
      this.map = new mapboxgl.Map({
      container: this.$refs.mapContainer,  // Selecciona el contenedor del mapa
      style: 'mapbox://styles/mapbox/streets-v11',  // Estilo del mapa
      center: [-74.006, 40.7128],  // Coordenadas [longitud, latitud] (Ejemplo: Nueva York)
      zoom: 12  // Nivel de zoom inicial
    });

    // Opcional: Agrega un control de zoom y rotación
    this.map.addControl(new mapboxgl.NavigationControl());
  },
  beforeDestroy() {
    if (this.map) {
      this.map.remove();  // Limpia el mapa al destruir el componente
    }
  
    }
  }
</script>

<style scoped>
.v-btn.white--text {
  background-color: white;
  color: black !important;
}
.map-container {
  width: 100%;
  height: 500px;  /* Ajusta la altura según lo que necesites */
}
</style>