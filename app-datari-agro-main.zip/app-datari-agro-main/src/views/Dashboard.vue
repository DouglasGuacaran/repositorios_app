<template>
  <v-app>
    <v-app-bar app dark elevation="0" clipped-left color="blue darken-4">
      <v-app-bar-nav-icon @click.stop="menulateral = !menulateral"></v-app-bar-nav-icon>
      <v-toolbar-title>
        <div class="d-flex align-center">
          <v-img
            alt="labict logo"
            class="shrink"
            contain
            src="@/media/logo_blanco.png"
            transition="scale-transition"
            width="120"
            height="30"
          />
        </div>
      </v-toolbar-title>
      <v-spacer></v-spacer>
      <v-icon>mdi-account</v-icon>
      <span class="ml-1 mr-2">{{ user }}</span>
      <v-btn @click="logout" v-if="isLoggedIn" text>
        <v-icon>mdi-power-cycle</v-icon>
      </v-btn>
    </v-app-bar>
    <v-navigation-drawer v-model="menulateral" floating app :permanent="menulateral" clipped width="295" dark color="blue darken-3">
      <v-list nav class="mt-1 d-flex flex-column" height="95%">
        <v-list-item class="px-0" link :to="{ path: '/' }" active-class="white--text blue darken-3">
          <v-list-item-avatar>
            <v-icon>mdi-home-outline</v-icon>
          </v-list-item-avatar>
          <v-list-item-content>
            <h4 class="font-weight-medium">Home</h4>
          </v-list-item-content>
        </v-list-item>

        <v-list-item class="px-0" link :to="{ path: '/caracterizacion/' }" active-class="white--text blue darken-3">
          <v-list-item-avatar>
            <v-icon>mdi-file-plus-outline</v-icon>
          </v-list-item-avatar>
          <v-list-item-content>
            <h4 class="font-weight-medium">Resultados Generales</h4>
          </v-list-item-content>
        </v-list-item>
        <div v-if="userRole == 'admin'">
          <v-list-item class="px-0" link :to="{ path: '#' }" active-class="white--text blue darken-3">
            <v-list-item-avatar>
              <v-icon>mdi-file-plus-outline</v-icon>
            </v-list-item-avatar>
            <v-list-item-content>
              <h4 class="font-weight-medium">Resultados Detalle</h4>
            </v-list-item-content>
          </v-list-item>
        </div>
        <div v-else>

        </div>
        <v-divider class="mb-2"></v-divider>
        <div id="lista_proyectos">
          <div class="text-center">
            <v-progress-circular v-if="loading" :size="30" color="dark" indeterminate class="mt-4"></v-progress-circular>
          </div>
          
        </div>
      </v-list>
    </v-navigation-drawer>
    <v-main style="background-color:#D5D8DC">
      <v-container fluid transition="fade-transition">
        <router-view
          :loading="loading"
        >
        </router-view>
      </v-container>
    </v-main>
    <v-footer dark app padless>
      <span class="white--text ml-2"><small>LAB ICT &copy; {{ new Date().getFullYear() }}</small> </span>
    </v-footer>
  </v-app>
</template>


<script>

const API_URL = 'http://localhost:8000/'; // Ajusta a tu URL de backend

export default {
  name: 'Dashboard',
  data: () => ({
    userRole: localStorage.getItem('user_role'),
    menulateral: true,
    loading: false,
    user: localStorage.getItem('username'),
    user_id: localStorage.getItem('user_id'),
    new_proyectos: false,
  }),
  
  created() {
    this.loading = true;
  },
  computed: {
    isLoggedIn: function () {
      return this.$store.getters.isLoggedIn;
    },
    
  },
  methods: {
    
    logout() {
      this.$store.dispatch('logout').then(() => {
        this.$router.push('/index');
        this.sleep(4000).then(() => {
          this.$router.push('/login');
        });
      });
    },
    
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    },
  },
};
</script>

<style scoped>
.v-list-item {
  flex: 0;
}
</style>
