from django.urls import path
from django.urls.conf import include
from rest_framework import routers    
from .views import RegionView,ComunaView,CensoRegionView,CensoComunaView,\
PermisosEdificacionComunalesView,PermisosEdificacionRegionalesView,PobrezaMultidimensionalView,\
dataDOMView

routerAPI = routers.DefaultRouter()
routerAPI.register(r'regiones',RegionView,basename="regiones")
routerAPI.register(r'comunas',ComunaView,basename="comunas")
routerAPI.register(r'censo_region',CensoRegionView,basename="censo_region")
routerAPI.register(r'censo_comuna',CensoComunaView,basename="censo_comuna")
routerAPI.register(r'permisos_edificacion_region',PermisosEdificacionRegionalesView,basename="permisos_edificacion_region")
routerAPI.register(r'permisos_edificacion_comuna',PermisosEdificacionComunalesView,basename="permisos_edificacion_comuna")
routerAPI.register(r'pobreza_multidimensional',PobrezaMultidimensionalView,basename="pobreza_multidimensional")
routerAPI.register(r'data_dom',dataDOMView,basename="data_dom")

urlpatterns = [
	# path('upload_file/',include(routerFileUpload.urls)),
	path('',include(routerAPI.urls)),   
	# 	path('token/verify/', TokenVerifyView.as_view(), name='token-verify'),
# 	path('token/refresh/', get_refresh_view().as_view(), name='token_refresh')
]
