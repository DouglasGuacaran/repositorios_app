from rest_framework.serializers import Serializer, FileField, IntegerField, ModelSerializer
from .models import Region,Comuna, DatosRegionalesCenso, DatosComunalesCenso, \
PermisosEdificacionRegionales, PermisosEdificacionComunales, PobrezaMultidimensional, \
data_DOM_regional


class RegionSerializer(ModelSerializer): 
    class Meta:
        model = Region
        fields = (
                    'id', 'nombre', 'numero_region','lat','lon','color',
                    'order'
                )

class ComunaSerializer(ModelSerializer):
	region = RegionSerializer()
	class Meta:
		model  = Comuna
		fields = (
			'id','nombre','lat','lon','codigo','region'
		)

class dataDOMSerializer(ModelSerializer):
	# region = RegionSerializer()
	# comuna = ComunaSerializer()

	class Meta:
		model = data_DOM_regional
		fields = (
			'id','nombre','comuna','region'
		)



class PermisosEdificacionRegionalesSerializer(ModelSerializer):
	class Meta:
		model = PermisosEdificacionRegionales
		fields = '__all__'

class PermisosEdificacionComunalesSerializer(ModelSerializer):
	class Meta:
		model = PermisosEdificacionComunales
		fields = '__all__'
		
class CensoRegionSerializer(ModelSerializer):

	class Meta:
		model = DatosRegionalesCenso
		fields = (
			'cantidad_habitantes','cantidad_viviendas',
			'cantidad_hombres','cantidad_mujeres',
			'densidad_poblacion','residentes_migrantes',
			'porcentaje_poblacion_migrante','porcentaje_pueblos_originarios',
			'porcentaje_empleo_mujeres','porcentaje_hacinamiento','cantidad_hogares',
			'anio_censo','region'
		)

class CensoComunaSerializer(ModelSerializer):

	class Meta:
		model = DatosComunalesCenso
		fields = (
			'cantidad_habitantes','cantidad_viviendas',
			'cantidad_hombres','cantidad_mujeres',
			'densidad_poblacion','residentes_migrantes',
			'porcentaje_poblacion_migrante','porcentaje_pueblos_originarios',
			'porcentaje_empleo_mujeres','porcentaje_hacinamiento','cantidad_hogares',
			'anio_censo','comuna','region'
		)

class PobrezaMultidimensionalSerializer(ModelSerializer):
	region = RegionSerializer()
	comuna = ComunaSerializer()
	class Meta:
		model = PobrezaMultidimensional
		fields = (
			'anio','cantidad_personas','porcentaje_pobreza','comuna','region'
		)



