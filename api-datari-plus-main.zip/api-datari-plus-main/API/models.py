from django.db import models

# Create your models here.
class Region(models.Model):

	nombre = models.CharField(max_length=200)
	numero_region = models.IntegerField()
	color = models.CharField(max_length=120,null=True)
	lat = models.FloatField(null=True)
	lon = models.FloatField(null=True)
	order = models.IntegerField(null=True)
	
	class Meta:
		verbose_name = "Region"
		verbose_name_plural = "Regiones"


	def __str__(self):
		return self.nombre


class Comuna(models.Model):

	nombre = models.CharField(max_length=200)
	lat = models.FloatField()
	lon = models.FloatField()
	codigo = models.IntegerField()
	region = models.ForeignKey(Region,on_delete=models.CASCADE)

	def __str__(self):
		return self.nombre


class data_DOM_regional(models.Model):
	nombre = models.CharField(max_length=200)
	comuna = models.ForeignKey(Comuna,on_delete = models.CASCADE)
	region = models.ForeignKey(Region, on_delete = models.CASCADE)

	def __str__(self):
		return self.nombre


class PermisosEdificacionRegionales(models.Model):

	anio = models.IntegerField()
	numero_permisos = models.IntegerField()
	unidades_casa = models.IntegerField()
	unidades_departamento = models.IntegerField()
	unidades_comercio = models.IntegerField()
	unidades_servicio = models.IntegerField()
	total_unidades = models.IntegerField()
	tipo = models.CharField(max_length=50)
	region = models.ForeignKey(Region,on_delete=models.CASCADE)

class PermisosEdificacionComunales(models.Model):

	anio = models.IntegerField()
	numero_permisos = models.IntegerField()
	unidades_casa = models.IntegerField()
	unidades_departamento = models.IntegerField()
	unidades_comercio = models.IntegerField()
	unidades_servicio = models.IntegerField()
	total_unidades = models.IntegerField()
	tipo = models.CharField(max_length=50)
	region = models.ForeignKey(Region,on_delete=models.CASCADE)
	comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)


class PobrezaMultidimensional(models.Model):
	anio = models.IntegerField()
	cantidad_personas = models.IntegerField()
	porcentaje_pobreza = models.FloatField()
	comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)
	region = models.ForeignKey(Region, on_delete=models.CASCADE)


class DatosRegionalesCenso(models.Model):

	cantidad_habitantes = models.IntegerField(null=True)
	cantidad_viviendas = models.IntegerField(null=True)
	cantidad_hombres = models.IntegerField(null = True)
	cantidad_mujeres = models.IntegerField(null = True)
	densidad_poblacion = models.FloatField(null = True)
	residentes_migrantes = models.IntegerField(null = True)
	porcentaje_poblacion_migrante = models.FloatField(null = True)
	porcentaje_pueblos_originarios = models.FloatField(null = True)
	porcentaje_empleo_mujeres = models.FloatField(null=True)
	porcentaje_hacinamiento = models.FloatField(null = True)
	cantidad_hogares= models.IntegerField(null=True)
	anio_censo = models.IntegerField()
	region = models.ForeignKey(Region, on_delete=models.CASCADE, null=True)

	class Meta:
	    verbose_name = "Datos Regionales Censo 2017"
	    verbose_name_plural = "Datos Regionales Censo 2017"


class DatosComunalesCenso(models.Model):

	cantidad_habitantes = models.IntegerField(null=True)
	cantidad_viviendas = models.IntegerField(null=True)
	cantidad_hombres = models.IntegerField(null = True)
	cantidad_mujeres = models.IntegerField(null = True)
	densidad_poblacion = models.FloatField(null = True)
	residentes_migrantes = models.IntegerField(null = True)
	porcentaje_poblacion_migrante = models.FloatField(null = True)
	porcentaje_pueblos_originarios = models.FloatField(null = True)
	porcentaje_empleo_mujeres = models.FloatField(null=True)
	porcentaje_hacinamiento = models.FloatField(null = True)
	cantidad_hogares= models.IntegerField(null=True)
	anio_censo = models.IntegerField()
	comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE,null=True)
	region = models.ForeignKey(Region, on_delete = models.CASCADE)
	
	class Meta:
		verbose_name = "Dato Comunal Censo 2017"
		verbose_name_plural = "Datos Comunales Censo 2017"
