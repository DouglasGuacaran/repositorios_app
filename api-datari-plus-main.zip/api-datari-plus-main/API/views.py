from django.shortcuts import render
from rest_framework.parsers import MultiPartParser, FileUploadParser
# from rest_framework.views import APIView
from rest_framework.viewsets import ViewSet, ModelViewSet
from rest_framework.response import Response
from .serializers import  RegionSerializer,ComunaSerializer,\
CensoRegionSerializer,CensoComunaSerializer,\
PermisosEdificacionComunalesSerializer, PermisosEdificacionRegionalesSerializer,\
PobrezaMultidimensionalSerializer, dataDOMSerializer
from .models import Region,Comuna,DatosRegionalesCenso,DatosComunalesCenso,\
PermisosEdificacionRegionales,PermisosEdificacionComunales, PobrezaMultidimensional, \
data_DOM_regional

import json
from rest_framework.permissions import IsAuthenticated

class RegionView(ModelViewSet):
	serializer_class = RegionSerializer        
	queryset = Region.objects.all().order_by('order')
	# authentication_classes = (TokenAuthentication,SessionAuthentication)
	permission_classes = (IsAuthenticated,)
	filterset_fields = ('nombre','numero_region')

class ComunaView(ModelViewSet):
	serializer_class = ComunaSerializer
	queryset = Comuna.objects.all().order_by('nombre')
	filterset_fields = ('nombre','region','codigo')
	permission_classes = (IsAuthenticated,)

class dataDOMView(ModelViewSet):
	serializer_class = dataDOMSerializer
	queryset = data_DOM_regional.objects.all()
	# queryset = data_DOM_regional.objects.all().order_by('region__order')
	filterset_fields = ('nombre','region','comuna')
	permission_classes = (IsAuthenticated,)	


class CensoRegionView(ModelViewSet):
	serializer_class = 	CensoRegionSerializer
	queryset = DatosRegionalesCenso.objects.all()
	filterset_fields = ('region',)
	permission_classes = (IsAuthenticated,)

class CensoComunaView(ModelViewSet):
	serializer_class = 	CensoComunaSerializer
	queryset = DatosComunalesCenso.objects.all()
	filterset_fields = ('comuna','region')
	permission_classes = (IsAuthenticated,)

class PermisosEdificacionRegionalesView(ModelViewSet):
	serializer_class = PermisosEdificacionRegionalesSerializer
	queryset = PermisosEdificacionRegionales.objects.all()
	filterset_fields = ('region','tipo')
	permission_classes = (IsAuthenticated,)

class PermisosEdificacionComunalesView(ModelViewSet):
	serializer_class = PermisosEdificacionComunalesSerializer
	queryset = PermisosEdificacionComunales.objects.all()
	filterset_fields = ('region','tipo')
	permission_classes = (IsAuthenticated,)

class PobrezaMultidimensionalView(ModelViewSet):
	serializer_class = PobrezaMultidimensionalSerializer
	queryset = PobrezaMultidimensional.objects.all()
	filterset_fields = ('anio','region','comuna')
	permission_classes = (IsAuthenticated,)

