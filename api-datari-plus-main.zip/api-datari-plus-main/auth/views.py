from django.shortcuts import render
from rest_framework.viewsets import ViewSet, ModelViewSet
from rest_framework import generics
from .serializers import UserSerializer


# class UserView(generics.ListAPIView):
# 	queryset = User.objects.all()
# 	serializer_class = UserSerializer

# Create your views here.
