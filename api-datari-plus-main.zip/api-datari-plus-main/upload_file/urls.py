from django.urls import path
from django.urls.conf import include
from rest_framework import routers    
from .views import UploadViewSet,ProjectView


routerFileUpload = routers.DefaultRouter()
routerFileUpload.register(r'upload',UploadViewSet,basename="upload")
routerFileUpload.register(r'project', ProjectView,basename="project")


urlpatterns = [
	path('',include(routerFileUpload.urls)),
]