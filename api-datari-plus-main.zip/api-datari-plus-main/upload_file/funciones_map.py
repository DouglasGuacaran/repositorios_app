def generate_geojson_point(properties_data,coordinates_data):

	data = {
		"type": "Feature",
		"geometry":{
			"type": "Point",
			"coordinates":coordinates_data
		},
		"properties": properties_data
	}

	return data