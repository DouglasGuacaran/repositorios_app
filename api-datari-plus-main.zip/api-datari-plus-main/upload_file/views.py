from django.shortcuts import render
# from rest_framework.parsers import MultiPartParser, FileUploadParser
from rest_framework.response import Response
from rest_framework.viewsets import ViewSet, ModelViewSet
# from rest_framework.views import APIView
from pyexcel_xlsx import get_data
import json
from rest_framework.permissions import IsAuthenticated


from .serializers import UploadSerializer, ProjectSerializer
from .models import Project

from .funciones import firstup_restlow,format_names,clean_string,\
create_list_from_string, count_elements_from_list, order_dicc_desc,\
get_max_min_variable,get_total_variable, get_ultimos_elementos

from .funciones_libro import tipo_de_archivo_segun_variables, crear_data_libro


class ProjectView(ModelViewSet):
	serializer_class = ProjectSerializer
	queryset = Project.objects.all()
	permission_classes = (IsAuthenticated,)
	filterset_fields = ('nombre','owner_id')



class UploadViewSet(ViewSet):
	serializer_class = UploadSerializer
	permission_classes = (IsAuthenticated,)

	def list(self, request):
		return Response("Vista GET - Subir archivo")

	def create(self, request):
		
		#Usar para autenticacion con cookies
		# user = request.user
		# id_user = user.pk

		id_user = request.POST['id_user']
		nombre_proyecto = request.POST['project_name']
		titulo_proyecto = request.POST['project_title']
		cant_proyectos = len(Project.objects.filter(owner_id=id_user))

		file_uploaded = request.FILES.get('file_uploaded')
		content_type = file_uploaded.content_type


		#CONVERT EXCEL EN LISTA Y DICCIONARIOS
		data = get_data(file_uploaded)
		nombre_archivo = file_uploaded.name
		libros = data


		cantidad_libros = len(libros)

		if cantidad_libros == 1:
			categorias_variables = self.get_categorias_variables(libros)
			data_final = {'variables_categorias':'','data':[]}

		else:

			data_final_result = []

			for libro in libros:

				data_libro = libros[libro]
				cant_filas_libro = len(data_libro)

				categorias = data_libro[0]
				variables_libro = data_libro[1]
				cant_variables = len(variables_libro)
				#Donde comienzan los datos
				pos_data_var = 2

				propiedades_libro = {
					'cant_variables': cant_variables,
					'pos_data_var': pos_data_var,
					'variables_libro':variables_libro,
					'categorias_libro': categorias,
					'data_libro':data_libro
				}

				tipo_archivo = tipo_de_archivo_segun_variables(variables_libro)

				data_result_libro = crear_data_libro(tipo_archivo,propiedades_libro)

				data_final_result.append(data_result_libro)
				
		



		response = {
			'proyecto_nombre': nombre_proyecto,
			'proyecto_titulo': titulo_proyecto,
			'numero_proyecto': 'project_'+str(cant_proyectos+1),
			'archivo':nombre_archivo,
			'dashboards': [
				{
					'nombre': 'Resultados Generales',
					'categorias': ['Caracterización','Infraestructura Digital'],
					'url':'dash_1'
				},
				{
					'nombre':'Resultados Detalle',
					'categorias': ['region','comuna'],
					'url':'dash_2'
				}
			],
			'tipo_libro': content_type,
			'cant_libros':cantidad_libros,
			'data_libros': data_final_result,
		
		}

		
		return Response(response)



