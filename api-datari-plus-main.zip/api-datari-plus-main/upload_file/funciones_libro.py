from .funciones_map import generate_geojson_point 

from .funciones_api import get_data_region, get_data_comuna,\
get_data_DOM_total, get_porcentajes_por_region_DOM


from .funciones import format_names,get_total_variable,get_ranking_desc_comuna,\
get_ranking_asc_comuna, get_numero_repeticiones,get_numero_repeticiones_list,\
get_numero_repeticiones_number, get_ranking_comuna_extremos, get_porcentaje


charts_by_number_elements = {
	2: ['simple_ranking','stack_column'],
	3: ['column','donut','pie','stack_column'],
	4:['column','donut','pie'],
	5: ['column','donut','pie','tree_map'],
	6: ['donut','pie','tree_map'],
	7:['donut','pie','tree_map'],
	8:['donut','pie','tree_map'],
	9: ['tree_map','donut','pie'],
	10:['tree_map','donut'],
	11:['tree_map','donut'],
	12: ['tree_map']
}

def get_index_var(variable,variables_libro):

	try:
		index_var = variables_libro.index(variable)
		return index_var
	except Exception as e:
		return -1

def tipo_de_archivo_segun_variables(variables_libro):

	region_options = ['Región','Region','region','región']
	comuna_options = ['Comuna','comuna']
	tipo_archivo = ''

	if(len(variables_libro) > 0):


		for region_option in region_options:

			index_var_region = get_index_var(region_option,variables_libro)

			#Existe region en variables
			if(index_var_region != -1):
				variables_libro[index_var_region] = 'region'

				for comuna_option in comuna_options:
					index_var_comuna = get_index_var(comuna_option,variables_libro)

					#Existe comuna en variables
					if(index_var_comuna != -1):

						variables_libro[index_var_comuna] = 'comuna'
						tipo_archivo = 'region_comuna'
					
					else:
						tipo_archivo = 'region'

		return tipo_archivo


def check_names(var_name):

	if (var_name == 'Indique si el PRC está actualmente en proceso de modificación'):
		result_var = 'PRC En modificación'

	elif (var_name == 'Califique calidad de infraestructura física de la DOM (escala de deficiente 1 a 5 muy buena)'):
		result_var = 'Calidad Infraestructura'

	elif (var_name == 'Indique el año del PRC vigente'):
		result_var = 'PRC'

	elif(var_name == 'Modalidad de atención de público durante pandemia'):
		result_var = 'Modalidad de atención'

	elif( var_name == 'Adquisición nuevos computadores en los últimos cinco años'):
		result_var = 'Adquisición computadores'
	
	else:
		result_var = var_name

	return result_var

def get_categorias_variables(categorias,variables,cant_variables):

	dict_cat_var = {}

	for i in range(0,cant_variables):
		variable = variables[i].strip()

		if variable != 'region' and variable != 'comuna':

			categoria = categorias[i].strip()

			if categoria not in dict_cat_var.keys():
				
				dict_cat_var[categoria] = [
					{
						'variable': variable,
						'pos': i
					}
				]

			else:

				data = {
					'variable':variable,
					'pos': i
				}

				dict_cat_var[categoria].append(data)

	data_result = {
		'num_categorias': len(dict_cat_var.keys()),
		'variables': dict_cat_var 
	}
	
	return data_result
	
def get_data_detail_libro_region_comuna(data_libro, pos_data,variables_libro,cant_variables):


	cant_datos = len(data_libro)
	data_variables = data_libro[pos_data:cant_datos]
	data_result = []

	for dato in data_variables:

		if dato != []:

			cant_datos_detail = len(dato)
			dict_detail = {}

			#Es dato por variable por lo que deben ser la misma cantidad.
			if (cant_datos_detail == cant_variables):

				dict_detail_file_data = {}

				for i in range(0,cant_datos_detail):

					if (variables_libro[i] == 'region'):
						region = dato[i]
						data_region = get_data_region(region)
						dict_detail['data_region'] = data_region
 
					elif (variables_libro[i] == 'comuna'):
						comuna = format_names(dato[i])
						data_comuna = get_data_comuna(comuna)
						dict_detail['data_comuna'] = data_comuna

					else:
						variable = variables_libro[i].strip()
						value_var = dato[i]
						dict_detail_file_data[variable] = value_var

				#se agrega dict de data file a dict principal por detail
				dict_detail['data_libro'] = dict_detail_file_data

				data_result.append(dict_detail)
	

	return data_result


def get_data_prc(data,variable):

	list_posee = []
	list_no_posee = []
	

	for dato in data:

		var_option = dato['data_comuna']['nombre']
		data_libro = dato['data_libro']
		value_variable = data_libro[variable]

		if (isinstance(value_variable,int)):
			
			data_temp = {
				'option':var_option,
				'value': value_variable 
			}

			list_posee.append(data_temp)

		else:

			data_temp = {
				'option':var_option
			}

			list_no_posee.append(data_temp)

	list_posee = sorted(list_posee,key=lambda i:i['value'],reverse=True)

	cantidad_con_dom = len(list_posee)
	cantidad_sin_dom = len(list_no_posee)

	list_posee_ultimos_5 = list_posee[0:6]

	data_result = {
		'cantidad_prc': cantidad_con_dom,
		'cantidad_sin_prc': cantidad_sin_dom,
		'list_no_posee': list_no_posee,
		'list_ultimos_prc': list_posee_ultimos_5,
		'list_proporcion':[
			{'option':'Comunas con PRC','cant': cantidad_con_dom},
			{'option':'Comunas sin PRC','cant': cantidad_sin_dom}
		]
	}

	return data_result



def get_data_total_caract_libro_region_comuna(data_libro,variables_categoria,regiones_comunas):

	if(variables_categoria['num_categorias'] > 0):

		data_result = []

		variables=variables_categoria['variables']


		cantidad_respuestas = len(data_libro)
		cantidad_total = get_data_DOM_total(regiones_comunas['regiones'])
		cantidad_no_respuestas = cantidad_total-cantidad_respuestas
		porcentaje_respuestas = get_porcentaje(cantidad_respuestas,cantidad_total)
		porcentaje_respuestas_region = get_porcentajes_por_region_DOM(regiones_comunas['region_comunas'])
		
		data_var_1 = {
			'varID':1,
			'variable': 'Participación',
			'cant_respuestas': cantidad_respuestas,
			'cant_total': cantidad_total,
			'porcentaje': porcentaje_respuestas,
			'data_list':[
				{'option': 'Participaron', 'cant': cantidad_respuestas },
				{'option':'No Participaron','cant':cantidad_no_respuestas}
			],
			'charts': ['donut'],
			'selected': 'donut'
		}

		data_var_2 = {
			'varID': 2,
			'variable': 'Participación Regional',
			'data_list': porcentaje_respuestas_region,
			'cant_datos': len(porcentaje_respuestas_region),
			'charts': ['card_ranking'],
			'selected': 'card_ranking',
		}

		data_result.append(data_var_1)

		data_result.append(data_var_2)


		#funcionarios
		var_3 = variables['CAPITAL HUMANO'][0]['variable']
		total_funcionarios = get_total_variable(data_libro,var_3)
		ranking_desc_funcionarios = get_ranking_desc_comuna(data_libro,var_3)
		ranking_asc_funcionarios = get_ranking_asc_comuna(data_libro,var_3)

		data_var_3 = {
			'varID': 3,
			'variable': check_names(var_3),
			'total': total_funcionarios,
			'data_list': {
				'max': ranking_desc_funcionarios[0:10],
				'min': ranking_asc_funcionarios[0:10]
			},
			'cant_datos': 4,
			'charts':['ranking'],
			'selected': 'ranking'
		}

		data_result.append(data_var_3)

	
		var_4 = variables['PLAN REGULADOR COMUNAL'][0]['variable']
		data_prc = get_data_prc(data_libro,var_4)

		data_var_4 = {
			'varID':4,
			'variable': check_names(var_4),
			'cantidad_prc': data_prc['cantidad_prc'],
			'cantidad_sin_prc':data_prc['cantidad_sin_prc'],
			'list_ultimos_prc': data_prc['list_ultimos_prc'],
			'data_list': data_prc['list_proporcion'],
			'charts':['pie'],
			'selected': 'pie'
		}

		data_result.append(data_var_4)

		var_5 = variables['PLAN REGULADOR COMUNAL'][0]['variable']
		data_var_5 = {
			'varID':5,
			'variable': 'Sin PRC',
			'cant_datos': len(data_prc['list_no_posee']),
			'data_list': data_prc['list_no_posee'],
			'charts': ['card_list'],
			'selected': 'card_list'
		}
		data_result.append(data_var_5)

		var_6 = variables['PLAN REGULADOR COMUNAL'][1]['variable']
		numero_repeticiones_var_6 = get_numero_repeticiones(data_libro,var_6)
		
		data_var_6 = {
			'varID':6,
			'variable': check_names(var_6),
			'data_list': numero_repeticiones_var_6,
			'cant_datos': len(numero_repeticiones_var_6),
			'charts': ['fill_column'],
			'selected': 'fill_column'
		}		

		data_result.append(data_var_6)

		# #calidad
		var_7 = variables['INFRAESTRUCTURA'][0]['variable']
		numero_repeticiones_var_7 = get_numero_repeticiones_number(data_libro,var_7)
		ranking_por_calidad = get_ranking_comuna_extremos(data_libro,var_7,1,5)
		ranking_por_calidad_mejores = ranking_por_calidad['ranking_max']
		ranking_por_calidad_peores = ranking_por_calidad['ranking_min'] 

		data_var_7 = {
			'varID': 7,
			'variable': check_names(var_7),
			'data_list': numero_repeticiones_var_7,
			'cant_datos': len(numero_repeticiones_var_7),
			'charts':['card_ranking'],
			'selected': 'card_ranking',
		}

		data_result.append(data_var_7)

		data_var_8 = {
			'varID': 8,
			'variable':check_names(var_7),
			'cant_datos':4,
			'data_list': {
				'max': ranking_por_calidad_mejores[0:10],
				'min': ranking_por_calidad_peores[0:10]
			},
			'charts':['ranking'],
			'selected': 'ranking'
		}

		data_result.append(data_var_8)


		# capacitacion

		cantidad_variables_capacitacion = len(variables['CAPACITACION'])

		if( cantidad_variables_capacitacion == 1):

			var_9 = variables['CAPACITACION'][0]['variable']
			numero_repeticiones_var_9 = get_numero_repeticiones(data_libro,var_9)

			data_var_9 = {
				'varID': 9,
				'variable':check_names(var_9),
				'data_list': numero_repeticiones_var_9,
				'cant_datos': len(numero_repeticiones_var_9),
				'charts':charts_by_number_elements[len(numero_repeticiones_var_9)],
				'selected': None
			}

			data_result.append(data_var_9)

		elif( cantidad_variables_capacitacion == 2):

			var_9 = variables['CAPACITACION'][0]['variable']
			numero_repeticiones_var_9 = get_numero_repeticiones_list(data_libro,var_9)

			data_var_9 = {
				'varID':9,
				'variable':check_names(var_9),
				'data_list': numero_repeticiones_var_9,
				'cant_datos': len(numero_repeticiones_var_9),
				'charts': charts_by_number_elements[len(numero_repeticiones_var_9)],
				'selected': None
			}

			data_result.append(data_var_9)

			var_10 = variables['CAPACITACION'][1]['variable']
			numero_repeticiones_var_10 = get_numero_repeticiones(data_libro,var_10)

			data_var_10 = {
				'varID': 10,
				'variable':check_names(var_10),
				'data_list': numero_repeticiones_var_10,
				'cant_datos': len(numero_repeticiones_var_10),
				'charts':charts_by_number_elements[len(numero_repeticiones_var_10)],
				'selected': None
			}

			data_result.append(data_var_10)


		
		return data_result


	
def get_data_total_inf_digital_libro_region_comuna(data_libro,pos_data,variables_categoria):

	if(variables_categoria['num_categorias'] > 0):

		variables = variables_categoria['variables']

		# print(variables)
		
		# print(variables_categoria)
		#cant computadores


		#Plataforma
		var_1 = variables['TRAMITES Y FUNCIONAMIENTO'][2]['variable']
		numero_repeticiones_var_1 = get_numero_repeticiones_list(data_libro,var_1)

		data_var_1 = {
			'varID':1,
			'variable': check_names(var_1),
			'data_list': numero_repeticiones_var_1,
			'cant_datos': len(numero_repeticiones_var_1),
			'charts': charts_by_number_elements[len(numero_repeticiones_var_1)],
			'selected': None
		}


		#Sistemas de pago
		var_2 = variables['TRAMITES Y FUNCIONAMIENTO'][0]['variable']
		numero_repeticiones_var_2 = get_numero_repeticiones_list(data_libro,var_2)


		data_var_2 = {
			'varID':2,
			'variable': check_names(var_2),
			'data_list': numero_repeticiones_var_2,
			'cant_datos': len(numero_repeticiones_var_2),
			'charts':charts_by_number_elements[len(numero_repeticiones_var_2)],
			'selected': None
		}

		#Computadores
		var_3 = variables['INFRAESTRUCTURA DIGITAL'][0]['variable']
		total_computadores = get_total_variable(data_libro,var_3)
		ranking_desc_computadores = get_ranking_desc_comuna(data_libro,var_3)
		ranking_asc_computadores = get_ranking_asc_comuna(data_libro,var_3)

		data_var_3 = {
			'varID':3,
			'variable': check_names(var_3),
			'total': total_computadores,
			'data_list':{
				'max': ranking_desc_computadores[0:10],
				'min': ranking_asc_computadores[0:10]
			},
			'cant_datos':4,
			'charts': ['ranking'],
			'selected': 'ranking'
		}

		#Adquisicion
		var_4 = variables['INFRAESTRUCTURA DIGITAL'][1]['variable']
		numero_repeticiones_var_4 = get_numero_repeticiones(data_libro,var_4)

		# selected_chart = 'simple_ranking' if len(numero_repeticiones_var_4) == 2 else None

		data_var_4 = {
			'varID':4,
			'variable': check_names(var_4),
			'data_list': numero_repeticiones_var_4,
			'cant_datos': len(numero_repeticiones_var_4),
			'charts': ['stack_column'],
			'selected': 'stack_column'
		}

		# simple_ranking' if len(numero_repeticiones_var_4) == 2 else None

		#Tipo software
		var_5 = variables['INFRAESTRUCTURA DIGITAL'][2]['variable']
		numero_repeticiones_var_5 = get_numero_repeticiones_list(data_libro,var_5)

		data_var_5 = {
			'varID':5,
			'variable': check_names(var_5),
			'data_list': numero_repeticiones_var_5,
			'cant_datos': len(numero_repeticiones_var_5),
			'charts':charts_by_number_elements[len(numero_repeticiones_var_5)],
			'selected': None
		}

		#tipo conexion
		var_6 = variables['INFRAESTRUCTURA DIGITAL'][3]['variable']
		numero_repeticiones_var_6 = get_numero_repeticiones(data_libro,var_6)

		data_var_6 = {
			'varID':6,
			'variable': check_names(var_6),
			'data_list': numero_repeticiones_var_6,
			'cant_datos': len(numero_repeticiones_var_6),
			'charts':charts_by_number_elements[len(numero_repeticiones_var_6)],
			'selected': None
		}

		#SIG
		var_7 = variables['TRAMITES Y FUNCIONAMIENTO'][1]['variable']
		numero_repeticiones_var_7 = get_numero_repeticiones(data_libro,var_7)

		data_var_7 = {
			'varID':7,
			'variable': check_names(var_7),
			'data_list': numero_repeticiones_var_7,
			'cant_datos': len(numero_repeticiones_var_7),
			'charts':['simple_ranking'],
			'selected': 'simple_ranking'
		}

		
		var_8 = variables['TRAMITES Y FUNCIONAMIENTO'][3]['variable']
		numero_repeticiones_var_8 = get_numero_repeticiones(data_libro,var_8)

		data_var_8 = {
			'varID':8,
			'variable': check_names(var_8),
			'data_list': numero_repeticiones_var_8,
			'cant_datos': len(numero_repeticiones_var_8),
			'charts':charts_by_number_elements[len(numero_repeticiones_var_8)],
			'selected': None
		}

		data_result = [
			data_var_1,
			data_var_2,
			data_var_3,
			data_var_4,
			data_var_5,
			data_var_6,
			data_var_7,
			data_var_8
		]

		return data_result



def get_region_comunas_disponibles(data):

	region_comunas_dict = {}

	data_sorted_by_region = sorted(data, key=lambda k: k['data_region']['orden'])

	for dato in data_sorted_by_region:

		region = dato['data_region']['nombre']
		comuna = dato['data_comuna']['nombre']

		if region not in region_comunas_dict.keys():
			
			region_comunas_dict[region] = [comuna]

		else:

			region_comunas_dict[region].append(comuna)

	data_result = {
		'cant_regiones': len(region_comunas_dict.keys()),
		'regiones': list(region_comunas_dict.keys()),
		'region_comunas': region_comunas_dict
	}

	return data_result

def get_mapa_region_comunas(data):
		
		data_mapa = {}


		


		# print(newlist) 

		
		for dato in data:


			region = dato['data_region']['nombre']
			comuna = dato['data_comuna']['nombre']
			data_libro = dato['data_libro']

			coordinates_comuna = [
				dato['data_comuna']['lon'],
				dato['data_comuna']['lat']
			]
			
			properties = {
				'nombre': comuna,
				'codigo': dato['data_comuna']['codigo'],
				'data_file': data_libro
			}

			if region not in data_mapa.keys():

				data_mapa[region] = {
					'data_region':{
						'coordinates':[
							dato['data_region']['lon'],
							dato['data_region']['lat']
						],
						'numero_region': dato['data_region']['numero_region'],
						'color_region':dato['data_region']['color'],
						'orden': dato['data_region']['orden']
					},
					'data_comunas': [generate_geojson_point(properties,coordinates_comuna)]
				}

			else:
				data_mapa[region]['data_comunas'].append(generate_geojson_point(properties,coordinates_comuna))

		cantidad_datos = len(data_mapa.keys())


		data_result = {
			'cant_datos':cantidad_datos,
			'data_mapa':data_mapa
		}


		return data_result

def crear_data_libro(tipo_archivo,propiedades_libro):

	categorias_libro = propiedades_libro['categorias_libro']
	variables_libro = propiedades_libro['variables_libro']
	cant_variables = propiedades_libro['cant_variables']
	pos_data_var = propiedades_libro['pos_data_var']
	data_libro = propiedades_libro['data_libro']


	if (tipo_archivo == 'region_comuna'):

		variables_categoria = get_categorias_variables(
			categorias_libro,variables_libro,cant_variables
		)

		data_detail_libro = get_data_detail_libro_region_comuna(
			data_libro, pos_data_var,variables_libro,cant_variables
		)

		regiones_comunas_disponibles_libro = get_region_comunas_disponibles(
			data_detail_libro
		)

		data_total_libro = [
			{
				'tipo': 'Caracterización',
				'data':get_data_total_caract_libro_region_comuna(
					data_detail_libro,
					variables_categoria, 
					regiones_comunas_disponibles_libro
				),
			},
			{
				'tipo': 'Infraestructura Digital',
				'data': get_data_total_inf_digital_libro_region_comuna(
					data_detail_libro,
					pos_data_var,
					variables_categoria
				)

			}
		]
		
		mapa_region_comunas = get_mapa_region_comunas(
			data_detail_libro
		)

		data_result_libro = {
			'data_total':data_total_libro,
			'data_detail': data_detail_libro,
			'data_mapa':mapa_region_comunas,
			'regiones_comunas': regiones_comunas_disponibles_libro,
			'variables_categorias': variables_categoria,
			
		}
	else:

		data_result_libro = {}

	return data_result_libro