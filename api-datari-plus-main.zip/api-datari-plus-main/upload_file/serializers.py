from rest_framework.serializers import Serializer, CharField, FileField,ReadOnlyField, IntegerField, ModelSerializer
from .models import Project


class ProjectSerializer(ModelSerializer):
	
	class Meta:
		model = Project
		fields = ['id','nombre','nombre_file','owner_id','file_json']


class UploadSerializer(Serializer):
	id_user = IntegerField()
	project_name = CharField(max_length=30)
	project_title = CharField(max_length=50)
	file_uploaded = FileField()
	
	class Meta:
		fields = ['id_user','project_name','project_title','file_uploaded']