from API.models import DatosRegionalesCenso, DatosComunalesCenso, PobrezaMultidimensional,\
PermisosEdificacionRegionales, PermisosEdificacionComunales,Region, Comuna,\
data_DOM_regional

from .funciones import normalizar_regiones, normalizar_comunas




def get_data_DOM_total(regiones_disponibles):
	
	total = 0

	for region in regiones_disponibles:

		data_region_DOM = data_DOM_regional.objects.filter(
			region__nombre = region
		)
		cantidad_DOM_region = len(data_region_DOM)
		total += cantidad_DOM_region

	return total

def get_porcentajes_por_region_DOM(regiones_comunas):

	regiones = Region.objects.all().order_by('order')

	data_result = []

	for region_object in regiones:
		if region_object.nombre != 'País':
			region = region_object.nombre

			data_region_DOM = data_DOM_regional.objects.filter(
				region__nombre = region
			)

			cantidad_DOM_region = len(data_region_DOM)

			if region in regiones_comunas.keys():
				cantidad_DOM_region_disponible = len(regiones_comunas[region])
				porcentaje_participacion_region = round(((cantidad_DOM_region_disponible/cantidad_DOM_region)*100),2)
				text = str(cantidad_DOM_region_disponible)+'/'+str(cantidad_DOM_region)	
				data_temp = {
					'region': region,
					'cant_respuestas':cantidad_DOM_region_disponible,
					'cant_esperada': cantidad_DOM_region,
					'porcentaje': porcentaje_participacion_region,
					'text':text
				}
			
				data_result.append(data_temp)
		

	return data_result


def get_data_censo(id_value,tipo):

		if tipo == 'region':
			datos_censo = DatosRegionalesCenso.objects.filter(region=id_value)

		elif tipo == 'comuna':
			datos_censo = DatosComunalesCenso.objects.filter(comuna=id_value)
			

		if len(datos_censo) == 0:
				
			data_result = {
				'cantidad_habitantes':'S/I',
				'cantidad_viviendas':'S/I',
				'densidad_poblacion':'S/I',
				'cantidad_hombres':'S/I',
				'cantidad_mujeres':'S/I',
				'porcentaje_poblacion_migrante':'S/I',
				'anio_censo':2017
			}

		else:
			datos_censo = datos_censo[0]


			data_result = {
				'cantidad_habitantes': datos_censo.cantidad_habitantes,
				'cantidad_viviendas':datos_censo.cantidad_viviendas,
				'densidad_poblacion':datos_censo.densidad_poblacion,
				'cantidad_hombres':datos_censo.cantidad_hombres,
				'cantidad_mujeres':datos_censo.cantidad_mujeres,
				'porcentaje_poblacion_migrante':datos_censo.porcentaje_poblacion_migrante,
				'anio_censo':datos_censo.anio_censo
			}

		return data_result

def get_data_pobreza_comuna(id_value):

	data_pobreza = PobrezaMultidimensional.objects.filter(comuna=id_value)

	if (len(data_pobreza) == 0):

		data_result = {
			'anio': 'S/I',
			'cantidad_personas':'S/I',
			'porcentaje_pobreza':'S/I',
			'anios': [2015,2017]
		}

	else:

		data_result = []
		
		for dato in data_pobreza:

			add_data = {
				'anio': dato.anio,
				'cantidad_personas':dato.cantidad_personas,
				'porcentaje_pobreza':dato.porcentaje_pobreza,
				'anios': [2015,2017]
			}

			data_result.append(add_data)

	return data_result

def get_data_total_permisos(data1,data2,result):

		size_data1 = len(data1)
		size_data2 = len(data2)

		if size_data1 == size_data2:

			for i in range(0,size_data1):

				anio = data1[i]['anio']
				n_permisos_obra_nueva = data1[i]['numero_permisos']
				n_permisos_ampliacion = data2[i]['numero_permisos']

				total_unidades_obra_nueva = data1[i]['total_unidades']
				total_unidades_ampliacion = data2[i]['total_unidades']

				total_permisos = n_permisos_ampliacion+n_permisos_obra_nueva
				total_unidades = total_unidades_ampliacion+total_unidades_obra_nueva

				data_temp = {
					'anio': anio,
					'numero_permisos': total_permisos,
					'total_unidades': total_unidades
				}

				result.append(data_temp)

def add_data_to_array_permisos(result,data):

		for dato in data:

			data_temp = {
				'anio':dato.anio,
				'numero_permisos': dato.numero_permisos,
				'total_unidades': dato.total_unidades
			}

			result.append(data_temp)

def get_data_permisos(id_value,tipo):

		if tipo == 'region':
			datos_permisos_obra_nueva = PermisosEdificacionRegionales.objects.filter(
				region=id_value,tipo='obra_nueva'
			)

			datos_permisos_ampliacion = PermisosEdificacionRegionales.objects.filter(
				region=id_value,tipo='ampliacion'
			)

		elif tipo == 'comuna':
			datos_permisos_obra_nueva = PermisosEdificacionComunales.objects.filter(
				comuna=id_value,tipo='obra_nueva'
			)

			datos_permisos_ampliacion = PermisosEdificacionComunales.objects.filter(
				comuna=id_value,tipo='ampliacion'
			)

		if len(datos_permisos_ampliacion or datos_permisos_obra_nueva) == 0:
				
			data_result = 'S/I'

		else:
			last_index = len(datos_permisos_obra_nueva)
			data_obra_nueva = datos_permisos_obra_nueva[last_index-6:last_index]
			data_ampliacion = datos_permisos_ampliacion[last_index-6:last_index]

			data_result_obra_nueva = []
			data_result_ampliacion = []

			add_data_to_array_permisos(data_result_obra_nueva,data_obra_nueva)
			add_data_to_array_permisos(data_result_ampliacion,data_ampliacion)
			
			data_total = []

			get_data_total_permisos(data_result_obra_nueva,data_result_ampliacion,data_total)

			data_result = {
				'obra_nueva': data_result_obra_nueva,
				'ampliacion': data_result_ampliacion,
				'total': data_total
			}

		return data_result

def get_data_region(region):
	
	nombre_region = normalizar_regiones(region)
	data_region = list(Region.objects.filter(nombre=nombre_region))

	if( len(data_region) > 0 ):
		data_region = data_region[0]
		id_region = data_region.id
		nombre = data_region.nombre
		lat = data_region.lat
		lon = data_region.lon	
		numero_region = data_region.numero_region
		order = data_region.order
		color = data_region.color
		
		data_result = {
			'nombre': nombre,
			'numero_region': numero_region,
			'lat': lat,
			'lon': lon,
			'orden': order,
			'color':color
		}
	else:
		data_result = {
			'nombre': None,
			'numero_region': None,
			'lat': None,
			'lon':None

		}

	return data_result
	
def get_data_comuna(comuna):
	nombre_comuna = normalizar_comunas(comuna)
	data_comuna = list(Comuna.objects.filter(nombre=nombre_comuna))

	if ( len(data_comuna) > 0 ):
		data_comuna = data_comuna[0]

		id_comuna = int(data_comuna.id)
		id_region = int(data_comuna.region.id)

		data_censo = get_data_censo(id_comuna,'comuna')
		data_pobreza = get_data_pobreza_comuna(id_comuna)
		data_permisos = get_data_permisos(id_comuna,'comuna')

		data_result = {
			'nombre': data_comuna.nombre,
			'lat': data_comuna.lat,
			'lon': data_comuna.lon,
			'codigo': data_comuna.codigo,
			'data_censo': data_censo,
			'data_pobreza': data_pobreza,
			'data_permisos':data_permisos
		}

	else:

		print(nombre_comuna)
		data_result = {}

	return data_result
	
		
	