from django.db import models


class Project(models.Model):

	nombre = models.CharField(max_length=1000)
	nombre_file = models.CharField(max_length=1000)
	file_json = models.JSONField()
	owner_id = models.IntegerField()


# Create your models here.
