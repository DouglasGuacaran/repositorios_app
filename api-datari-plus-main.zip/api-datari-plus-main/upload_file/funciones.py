#Funciones 
from collections import OrderedDict
import json



def normalizar_regiones(nombre_region):

	if( 'Araucanía' in nombre_region ):
		nombre_result = 'La Araucanía'
	
	elif( 'Los Lagos' in nombre_region ):
		nombre_result = 'Los Lagos'

	elif( 'Los Ríos' in nombre_region ):
		nombre_result = 'Los Ríos'

	elif( "O’Higgins" in nombre_region ):
		nombre_result = "O'Higgins"

	elif ( 'Aysén' in nombre_region ):
		nombre_result = 'Aysén'

	else:
		nombre_result = nombre_region

	return nombre_result

def normalizar_comunas(nombre_comuna):

	nombre_comuna = nombre_comuna.strip()

	nombres_correctos_segun_comuna = {
	'Copiapo': 'Copiapó','Combarbala': "Combarbalá",
	'Rio Hurtado': "Río Hurtado", 'Valparaiso': "Valparaíso",
	'Llay Llay': "LLAY LLAY", 'Juan Fernandez': "Juan Fernández",
	'Vilcun': "Vilcún", 'Curacautin': "Curacautín",'Tolten': "Toltén",
	'San Juan de La Costa': "San Juan de la Costa", 'Machali': "Machalí",
	'Curico': "Curicó", 'San Vicente': "San Vicente de Tagua Tagua",
	'Requinoa': "Requínoa", 'Chepica': "Chépica", 'Marchigüe': "Marchigue",
	'Constitucion': "Constitución",'Rio Claro': "Río Claro",'Peñalolen': "Peñalolén",
	'Til Til': "Tiltil", 'Maria Pinto': "María Pinto", 'Liquen': "Ñiquen",
	'Chillan Viejo':"Chillán Viejo", 'Comuna de Trehuaco': "Treguaco", 'San Nicolas': "San Nicolás",
	'Los Alamos': "Los Álamos", 'Mulchen': "Mulchén", 'Los Angeles': "Los Ángeles",
	'Hualpen': "Hualpén"
	}

	comunas_correctas_keys = nombres_correctos_segun_comuna.keys()

	if( nombre_comuna in comunas_correctas_keys ):
		nombre_result = nombres_correctos_segun_comuna[nombre_comuna]
	else:
		nombre_result = nombre_comuna

	return nombre_result


def abreviar_var(variable):

	if '(Office)' in variable:
		result = 'Ofimática'

	elif ('(CAD)' in variable) or ('Autocad' in variable):
		result = 'CAD'

	elif '(SIG)' in variable:
		result = 'GIS'

	elif 'Ethernet' in variable:
		result = 'Ethernet'

	elif 'No posee' in variable:
		result = 'No posee'

	elif 'Inalámbrico' in variable:
		result = 'Inalámbrico'

	elif 'Satelital' in variable:
		result = 'Satelital'

	elif 'Transferencia' in variable:
		result = 'Transferencia'

	elif 'Web Pay' in variable:
		result = 'WebPay'

	elif 'TGR' in variable:
		result = 'Pago TGR'

	elif 'Finanzas' in variable:
		result = 'Unidad Finanzas'

	elif 'TESORERIA' in variable or 'Tesorería' in variable:
		result = 'Tesorería Municipal'

	elif 'Ninguno' in variable:
		result = 'No posee'

	elif 'correo electrónico' in variable:
		result = 'Correo Electrónico'


	elif 'Mixto' in variable:
		result = 'Mixto'

	elif 'teletrabajo' in variable:
		result = 'Teletrabajo'

	elif 'presencial' in variable:
		result = 'Presencial'
	# elif 'Ley de Aportes al Espacio Público' in variable:
	# 	Ley

	else:
		result = variable

	return result

def firstup_restlow(text):

		first_letter = text[0].upper()
		rest = text[1:].lower()

		result = first_letter+rest

		return result

def format_names(nombre):

	nombre = nombre.strip()
	nombre = nombre.lower()

	if ' ' in nombre:
		temp = nombre.split(' ')
		text_result = ''
		for text in temp:
			if text != 'de' and text != 'del' and text != 'y':
				text_result += firstup_restlow(text)+' '
			elif text == temp[len(temp)-1]:
				text_result += firstup_restlow(text)
			else:
				text_result += text+' '
	else:
		text_result = firstup_restlow(nombre)

	return text_result.strip()

def clean_string(string):
		return string.strip()

def string_is_list(string):
	
	value = string.find(',')

	if(value != -1):
		return True
	else:
		return False	



def create_list_from_string(string,variable):

	exp = [
		'Sistemas de pago digital de la DOM',
		'Plataforma de gestión digital'
	]

	if(variable in exp) and (string_is_list(string)):
		# print(variable)
		temp_ = string.split(',')
		temp_list = list(map(clean_string,temp_))
		result = [temp_list[0]]
		
	else:
		
		if (',' in string):
			temp_string = string.split(',')
			temp_list = list(map(clean_string,temp_string))
			result = temp_list
		
		else:
			result = [string]


	return result

def count_elements_from_list(lista,dicc):

	for element in lista:
		element = abreviar_var(element)

		if (element not in dicc.keys()):
			dicc[element] = 1
		else:
			dicc[element] += 1

	return 0

def order_dicc_desc(dicc):
	result_dicc = OrderedDict(sorted(dicc.items(), key= lambda i: (i[1],i[0]),reverse=True))
	return result_dicc

def get_total_variable(data,variable):
		
	total = 0

	for dato in data:
		data_libro = dato['data_libro']
		data_variable = data_libro[variable]
		total += data_variable

	return total


def get_porcentaje(valor,total):

	return round(((valor*100.0)/total),2)

def convert_to_list_objects(dicc,total):

	options = list(dicc.keys())
	data_result = []
	cantidad_opciones = len(options)

	if( cantidad_opciones > 1 ):

		for option in options:

			if option != '':

				value = dicc[option]
				porcentaje = get_porcentaje(value,total)

				data_temp = {
					'option':option,
					'cant':value,
					'porcentaje': porcentaje
				}

				data_result.append(data_temp)

	elif( cantidad_opciones == 1 ):

		option_1 = options[0]
		value_1 = dicc[option_1]
		porcentaje_1 = get_porcentaje(value_1,total)

		if( option_1 == 'No' ):
			option_2 = 'Si'
		elif( option_1 == 'Si' ):
			option_2 = 'No'

		data_temp_1 = {
			'option': option_1,
			'cant': value_1,
			'porcentaje':porcentaje_1
		}

		data_temp_2 = {
			'option': option_2,
			'cant': 0,
			'porcentaje': 0
		}

		data_result.append(data_temp_1)
		data_result.append(data_temp_2)

	return data_result

def get_numero_repeticiones_list(data,variable):

	data_result = {}
	total = 0

	for dato in data:

		data_libro = dato['data_libro']
		options = create_list_from_string(data_libro[variable],variable)
		
		#Agrega opciones nuevas a diccionarios, y suma cantidad de selecciones
		count_elements_from_list(options,data_result)
		
		total += len(options)
		

	return convert_to_list_objects(data_result,total)

def get_numero_repeticiones(data,variable):

	data_result = {}
	total = 0

	for dato in data:

		data_libro = dato['data_libro']
		option = data_libro[variable]

		option = abreviar_var(option)

		if option not in data_result.keys():
			
			data_result[option] = 1
		
		else:
			data_result[option] += 1

		total+=1

	return convert_to_list_objects(data_result,total)

def get_numero_repeticiones_number(data,variable):

	data_result = {}
	total = 0

	for dato in data:

		data_libro = dato['data_libro']
		option = data_libro[variable]

		if option not in data_result.keys():
			
			data_result[option] = 1
		
		else:
			data_result[option] += 1

		total+=1

	data_list = convert_to_list_objects(data_result,total)

	return sorted(data_list,key = lambda i:i['option'])

def get_ranking_desc_comuna(data,variable):

	data_result = []

	for dato in data:
		data_libro = dato['data_libro']
		value = data_libro[variable]
		var_option = dato['data_comuna']['nombre']

		if value > 0:

			data_temp = {
				'comuna': var_option,
				'cant': value
			}
			data_result.append(data_temp)
	

	return sorted(data_result, key = lambda i:i['cant'],reverse=True)

def get_ranking_comuna_extremos(data,variable,min_value,max_value):

	data_result_min = []
	data_result_max = []

	for dato in data:
		data_libro = dato['data_libro']
		value = data_libro[variable]
		var_option = dato['data_comuna']['nombre']

		data_temp = {
			'comuna': var_option,
			'cant': value
		}

		if value == min_value:
			data_result_min.append(data_temp)
		elif value == max_value:
			data_result_max.append(data_temp)
			
	return {
		'ranking_max':data_result_max,
		'ranking_min':data_result_min
	} 



def get_ranking_asc_comuna(data,variable):

	data_result = []

	for dato in data:
		data_libro = dato['data_libro']
		value = data_libro[variable]
		var_option = dato['data_comuna']['nombre']

		if value > 0:

			data_temp = {
				'comuna': var_option,
				'cant': value
			}
			data_result.append(data_temp)
		
	
	return sorted(data_result, key = lambda i:i['cant'])

def get_max_min_variable(data,variable):

	max_item = max(data,key = lambda x:x['data_libro'][variable])
	min_item = min(data,key = lambda x:x['data_libro'][variable])

	return max_item,min_item

def bubble_sort_variable(list_data,variable):

	pass

def get_ultimos_elementos(list_data,variable):

	list_no_posee = []
	list_to_sort = []

	for element in list_data:
		value_var = element['data_libro'][variable]
		# print(value_var)
		if (isinstance(value_var,int)):
			list_to_sort.append(element)
		else:
			list_no_posee.append(element)

	# print(len(list_data))

	sorted_list = sorted(
		list_to_sort, 
		key = lambda i:int(i['data_libro'][variable]), 
		reverse=True
	)

	data_result = {
		'list_data': get_comuna_and_data(sorted_list[0:6],variable),
		'non_data_list': get_comuna_and_data(list_no_posee,variable)
	}

	return data_result

def limpiar_dato(self,dato):

		if (' /2' in dato):
			dato = dato.replace(' /2','')
		if('/3' in dato):
			dato = dato.replace(' /3','')
		else:
			dato

		return dato

	





