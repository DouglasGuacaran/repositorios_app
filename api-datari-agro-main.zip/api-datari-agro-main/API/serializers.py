from rest_framework import serializers
from .models import Productores, Cultivos, RecursosHidricos, Suelo, Residuos, Certificaciones, Comercializacion, Trazabilidad, Energia, Trabajadores

class ProductoresSerializer(serializers.ModelSerializer):
    class Meta:
        model = Productores
        fields = '__all__'
class EnergiaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Energia
        fields = '__all__'

class CultivosSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cultivos
        fields = '__all__'

class RecursosHidricosSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecursosHidricos
        fields = '__all__'

class SueloSerializer(serializers.ModelSerializer):
    class Meta:
        model = Suelo
        fields = '__all__'

class ResiduosSerializer(serializers.ModelSerializer):
    class Meta:
        model = Residuos
        fields = '__all__'

class CertificacionesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Certificaciones
        fields = '__all__'

class ComercializacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comercializacion
        fields = '__all__'

class TrazabilidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trazabilidad
        fields = '__all__'

class TrabajadoresSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trabajadores
        fields = '__all__'