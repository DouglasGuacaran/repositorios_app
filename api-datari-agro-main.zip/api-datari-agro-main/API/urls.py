from django.urls import path
from django.urls.conf import include
from rest_framework import routers  
from .views import ProductoresView, CultivosView,RecursosHidricosView,SueloView,ResiduosView,CertificacionesView,ComercializacionView,TrazabilidadView,EnergiaView, TrabajadoresView

routerAPI = routers.DefaultRouter()
routerAPI.register(r'productores', ProductoresView, basename="productores")
routerAPI.register(r'cultivos', CultivosView, basename="cultivos")
routerAPI.register(r'recursos_hidricos', RecursosHidricosView, basename="recursos_hidricos")
routerAPI.register(r'suelo', SueloView, basename="suelo")
routerAPI.register(r'residuos', ResiduosView, basename="residuos")
routerAPI.register(r'certificaciones', CertificacionesView, basename="certificaciones")
routerAPI.register(r'comercializacion', ComercializacionView, basename="comercializacion")
routerAPI.register(r'trazabilidad', TrazabilidadView, basename="trazabilidad")
routerAPI.register(r'trabajadores', TrabajadoresView, basename="trabajadores")
routerAPI.register(r'energia', EnergiaView, basename="energia")

urlpatterns = [
	path('',include(routerAPI.urls)),   
    ]
