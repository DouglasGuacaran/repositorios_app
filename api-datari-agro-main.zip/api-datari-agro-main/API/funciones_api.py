# def get_comuna_and_data(data,variable):
# 	result_list = []
# 	for element in data:
# 		data_temp = {
# 			'comuna': element['Comuna']['nombre'],
# 			'data': element['data_libro'][variable]
# 		}

# 		result_list.append(data_temp)

# 	return result_list