from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated

from .serializers import (
    ProductoresSerializer, CultivosSerializer, RecursosHidricosSerializer,
    SueloSerializer, ResiduosSerializer, CertificacionesSerializer,
    ComercializacionSerializer, TrazabilidadSerializer, EnergiaSerializer, TrabajadoresSerializer
)
from .models import (
    Productores, Cultivos, RecursosHidricos, Suelo,
    Residuos, Certificaciones, Comercializacion, Trazabilidad, Energia, Trabajadores
)

# Vista para Productores
class ProductoresView(ModelViewSet):
    serializer_class = ProductoresSerializer
    queryset = Productores.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Cultivos
class CultivosView(ModelViewSet):
    serializer_class = CultivosSerializer
    queryset = Cultivos.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Recursos Hídricos
class RecursosHidricosView(ModelViewSet):
    serializer_class = RecursosHidricosSerializer
    queryset = RecursosHidricos.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Suelo
class SueloView(ModelViewSet):
    serializer_class = SueloSerializer
    queryset = Suelo.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Residuos
class ResiduosView(ModelViewSet):
    serializer_class = ResiduosSerializer
    queryset = Residuos.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Certificaciones
class CertificacionesView(ModelViewSet):
    serializer_class = CertificacionesSerializer
    queryset = Certificaciones.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Comercialización
class ComercializacionView(ModelViewSet):
    serializer_class = ComercializacionSerializer
    queryset = Comercializacion.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Trazabilidad
class TrazabilidadView(ModelViewSet):
    serializer_class = TrazabilidadSerializer
    queryset = Trazabilidad.objects.all()
    permission_classes = (IsAuthenticated,)

# Vista para Energía
class EnergiaView(ModelViewSet):
    serializer_class = EnergiaSerializer
    queryset = Energia.objects.all()
    permission_classes = (IsAuthenticated,)

#Vista para Trabajadores    
class TrabajadoresView(ModelViewSet):
    serializer_class = TrabajadoresSerializer
    queryset = Trabajadores.objects.all()
    permission_classes = (IsAuthenticated,)