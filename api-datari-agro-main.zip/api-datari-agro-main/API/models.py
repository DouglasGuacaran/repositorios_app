from django.db import models

# Create your models here.
class Productores (models.Model):
    tipo_empresa = models.CharField(max_length=255)
    tamano_empresa = models.CharField(max_length=255)
    region = models.CharField(max_length=255)
    comuna = models.CharField(max_length=255)
    distancia_predio_arica = models.DecimalField(max_digits=5, decimal_places=2)
    ubicacion_predio = models.CharField(max_length=255)
    propiedad_predio = models.CharField(max_length=255)
    # rango_antiguedad_cultivo = models.CharField(max_length=50)
    # grado_pertinencia_cultivo = models.CharField(max_length=100)
    # calificacion_pertinencia = models.IntegerField()

    def __str__(self):
        return f"{self.tipo_empresa} - {self.region}"
    

class Cultivos(models.Model):
    productor_id = models.IntegerField()  # O ForeignKey 
    producto = models.CharField(max_length=255)
    produccion_anual = models.DecimalField(max_digits=10, decimal_places=2)
    frecuencia_cosecha_anual = models.IntegerField()
    practica_agricola = models.CharField(max_length=255)
    declaracion_practica_agricola = models.IntegerField()
    practicas_manejo_plagas = models.TextField()
    bps_practicas_manejo_plagas = models.IntegerField()
    grado_satisfaccion_cultivo = models.CharField(max_length=255)
    percepcion_practicas_cultivo = models.IntegerField()
    rango_antiguedad_cultivo = models.CharField(max_length=50)
    grado_pertinencia_cultivo = models.CharField(max_length=255)
    calificacion_pertinencia = models.IntegerField()

    def __str__(self):
        return f"{self.producto} - ID: {self.id}"
    
    
    
class RecursosHidricos(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    fuente_agua = models.CharField(max_length=255)
    cantidad_anual_agua_necesaria = models.DecimalField(max_digits=10, decimal_places=2)
    consumo_anual_agua = models.DecimalField(max_digits=10, decimal_places=2)
    sistema_riego = models.CharField(max_length=255)
    declaracion_eficiencia_riego = models.IntegerField()
    analisis_calidad_agua = models.CharField(max_length=255)
    declaracion_calidad_agua = models.TextField()
    frecuencia_analisis_agua = models.CharField(max_length=255)
    percepcion_practicas_uso_agua = models.IntegerField()
    declaracion_frecuencia_analisis_agua = models.IntegerField()
    grado_satisfaccion_practica_uso_agua = models.CharField(max_length=50)

    def __str__(self):
        return f"Recursos Hídricos - Cultivo ID: {self.cultivo.id}"

class Suelo(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    superficie_cultivada = models.CharField(max_length=100)
    cantidad_arboles = models.IntegerField(null=True, blank=True)
    analisis_suelo = models.CharField(max_length=255)
    declaracion_analisis_suelo = models.TextField()
    frecuencia_analisis_suelo = models.CharField(max_length=255)
    practicas_fertilidad_suelo = models.CharField(max_length=255)
    bps_practica_fertilidad_suelo = models.IntegerField()
    grado_satisfaccion_uso_suelo = models.CharField(max_length=100)
    percepcion_practicas_uso_suelo = models.IntegerField()

    def __str__(self):
        return f"Suelo - Cultivo ID: {self.cultivo.id}"	    

class Residuos(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    cantidad_residuos_organicos_anual = models.CharField(max_length=100)
    decl_rango_cantidad_residuos_organicos = models.IntegerField()
    realiza_gestion_residuos_organicos = models.CharField(max_length=50)
    decl_gestion_residuos_organicos = models.IntegerField()
    rango_porc_residuos_organicos_reciclado_reutilizado = models.CharField(max_length=50)
    decl_rango_porc_res_org_reciclado_reutilizados = models.CharField(max_length=75)
    rango_porc_residuos_organicos_compostaje = models.CharField(max_length=50)
    decl_residuos_organicos_compostaje = models.IntegerField()
    realiza_gestion_residuos_no_organicos = models.CharField(max_length=50)
    decl_residuos_no_organicos = models.IntegerField()
    grado_satisfaccion_practicas_gestion_residuos = models.CharField(max_length=50)
    percep_practicas_gestion_residuos = models.IntegerField()

    def __str__(self):
        return f"Residuos - Cultivo ID: {self.cultivo.id}"
class Energia(models.Model):
    registro_consumo_energia = models.CharField(max_length=255)
    bps_consumo_energia = models.IntegerField()
    consumo_anual_energia_kw = models.CharField(max_length=255)
    decl_consumo_energia_kw = models.IntegerField()
    rango_porc_consumo_energia_fuentes_renovables = models.CharField(max_length=50)
    decl_rango_porc_consumo_ener_fuentes_renovables = models.IntegerField()
    grado_satisfaccion_practicas_uso_energia = models.CharField(max_length=50)
    productor = models.ForeignKey(Productores, on_delete=models.CASCADE)  # Relación con Productores
    perc_practica_uso_energia = models.IntegerField()

    def __str__(self):
        return f"Energía - Productor ID: {self.productor.id}"
    
class Certificaciones(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    cert_act_sellos_reportes_producciones = models.TextField()
    decl_cert_sello_reportes_producciones = models.IntegerField()
    cert_sello_reporte_corto_plazo = models.CharField(max_length=50)
    decl_int_obt_cert_sello_reporte_declaraciones = models.IntegerField()
    ident_cert_sello_reporte_corto_plazo = models.TextField()

    def __str__(self):
        return f"Certificaciones - Cultivo ID: {self.cultivo.id}"
    
class Trabajadores(models.Model):
    productor = models.ForeignKey(Productores, on_delete=models.CASCADE)  # Relación con Productores
    total_trabajadores = models.IntegerField()
    mujeres_trabajadoras = models.IntegerField()
    trabajadores_contrato = models.IntegerField()
    trabajadores_postgrado = models.IntegerField()
    trabajadores_pregrado = models.IntegerField()
    trabajadores_tecnico = models.IntegerField()
    trabajadores_educacion_media = models.IntegerField()
    trabajadores_educacion_basica = models.IntegerField()
    trabajadores_educacion_basica_incompleta = models.IntegerField()
    formacion_educacional_participante = models.CharField(max_length=255)
    frecuencia_capacitacion_bpa = models.CharField(max_length=255)
    declaracion_capacitacion_trabajadores_bpa = models.IntegerField()
    frecuencia_capacitacion_seguridad = models.CharField(max_length=255)
    declaracion_capacitacion_seguridad = models.IntegerField()
    servicios_trabajadores_en_predio = models.TextField()
    politica_responsabilidad_social = models.TextField()
    bps_politica_resp_social = models.IntegerField()

    def __str__(self):
        return f"Trabajadores - Productor ID: {self.productor.id}"
    
class Comercializacion(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    participacion_de_emp_en_sector_agricola = models.CharField(max_length=255)
    porc_produccion_regional = models.DecimalField(max_digits=5, decimal_places=2)
    porc_produccion_nacional = models.DecimalField(max_digits=5, decimal_places=2)
    porc_produccion_internacional = models.DecimalField(max_digits=5, decimal_places=2)
    exportacion_corto_plazo = models.CharField(max_length=255)
    decl_proy_exp_corto_plazo = models.IntegerField()
    sistema_control_costo_produccion = models.TextField()
    bps_calculo_costos_produccion = models.IntegerField()
    evolucion_prod_ult_cinco_anios = models.CharField(max_length=255)
    decl_nivel_produccion = models.IntegerField()
    innovacion_puede_incrementar_produccion = models.CharField(max_length=255)
    calificacion_innovacion_incr_productividad = models.IntegerField()

    def __str__(self):
        return f"Comercialización - Cultivo ID: {self.cultivo.id}"
class Trazabilidad(models.Model):
    cultivo = models.ForeignKey(Cultivos, on_delete=models.CASCADE)  # Relación con Cultivos
    realiza_trazabilidad = models.CharField(max_length=50)
    declaracion_trazabilidad_cultivos = models.IntegerField()
    factibilidad_trazabilidad_producciones = models.TextField()
    bps_factibilidad_trazabilidad_producciones = models.IntegerField()
    forma_registro_produccion = models.CharField(max_length=255)
    decl_form_registro_produccion = models.IntegerField()
    frecuencia_registro_produccion = models.CharField(max_length=255)
    decla_frec_registro_produccion = models.IntegerField()
    frecuencia_uso_tecnologia_med_amb = models.CharField(max_length=255)
    dec_frec_uso_tecn_med_ambiente = models.IntegerField()

    def __str__(self):
        return f"Trazabilidad - Cultivo ID: {self.cultivo.id}"