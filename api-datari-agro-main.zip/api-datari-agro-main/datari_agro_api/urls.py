from django.contrib import admin
from django.urls import path, include
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework import permissions
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView


schema_view = get_schema_view(
    openapi.Info(
        title="DATARI+ API",
        default_version='v1',
        description="API Privada",
        terms_of_service="https://datari.net",
        contact=openapi.Contact(email="contacto@datari.net"),
        license=openapi.License(name="Test License"),
    ),
    # url="https://api.plus.datari.net/",
    public=True,
    permission_classes=(permissions.AllowAny,),
)


urlpatterns = [
    path('accounts/', admin.site.urls),
    path('api-agro/',include('API.urls')),
    path('auth/',include('auth.urls')),
    ## Se retira el file_management ya que no se cargaran proyectos
    # path('file_management/',include('upload_file.urls')),
    # path('', schema_view.with_ui(
    #     'swagger',cache_timeout=0), name='schema-swagger-ui'
    # ),
    path('api/api.json/', schema_view.with_ui(cache_timeout=0),
        name='schema-swagger-ui'
    ),
    path('',
        schema_view.with_ui('redoc',cache_timeout=0), name='schema-redoc'
    )

]
