
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User

class CustomLoginView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            access_token = response.data.get('access')
            refresh_token = response.data.get('refresh')

            user = User.objects.get(username=request.data.get('username'))

            user_data = {
                "pk": user.pk,
                "username": user.username,
                "email": user.email,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "is_staff":user.is_staff,
                "is_superuser":user.is_superuser
            }

            custom_response = {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "user": user_data
            }

            return Response(custom_response, status=status.HTTP_200_OK)
        return response
